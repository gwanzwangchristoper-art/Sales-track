import { saleHistory, correctSale } from '../domain/corrections.js';
import { can } from '../auth/permissions.js';
import { currentUser } from '../auth/auth.js';
import { money } from '../domain/calculator.js';
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const when = (t) => new Date(t).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' });

export async function renderSaleDetail(host, saleId, back) {
  const h = await saleHistory(saleId), s = h.sale;
  const canFix = can(currentUser(), 'corrections') && !s.corrects_sale_id && ['confirmed', 'corrected'].includes(s.status);
  host.innerHTML = `<h2>${esc(s.receipt_no)}</h2><p class="sub">${when(s.created_at)} · ${esc(s.who)} · ${esc(s.status)}</p>
  <div class="row"><b>Original transaction</b>${h.original.map(i => `<div class="ln"><span>${esc(i.name)}<br><small>${i.quantity} × ${money(i.unit_price)}</small></span><b>${money(i.subtotal)}</b></div>`).join('')}
  <div class="ln"><b>Total</b><b>${money(s.total)}</b></div></div>
  ${h.corrections.map(c => `<div class="row warn"><b>Correction ${esc(c.receipt_no)}</b><br><small>${when(c.created_at)} · ${esc(c.who)}</small>
    <div>Reason: ${esc(c.correction_reason)}</div>${c.items.map(i => `<div class="ln"><span>${esc(i.name)}</span><span>${i.quantity > 0 ? '+' : ''}${i.quantity}</span><b>${money(i.subtotal)}</b></div>`).join('')}</div>`).join('')}
  ${h.corrections.length ? `<div class="row"><b>Now</b>${h.items.map(i => `<div class="ln"><span>${esc(i.name)}</span><b>${i.quantity} × ${money(i.unit_price)}</b></div>`).join('')}</div>` : ''}
  ${canFix ? '<button class="btn" id="fix">Correct this sale</button>' : ''}<button class="btn alt" id="bk">Back</button>`;
  $('bk').onclick = back;
  $('fix')?.addEventListener('click', () => form(host, saleId, h, back));
}

function form(host, saleId, h, back) {
  host.innerHTML = `<h2>Correct ${esc(h.sale.receipt_no)}</h2><p class="sub">The original stays on record. Your change is added as a correction with your name and reason.</p>
  ${h.items.map(i => `<div class="row"><b>${esc(i.name)}</b><br><small>Recorded: ${i.quantity}</small><label>Correct quantity</label><input data-p="${i.product_id}" inputmode="decimal" value="${i.quantity}"></div>`).join('')}
  <label>Reason (required)</label><input id="why" placeholder="For example: wrong quantity entered">
  <div class="err" id="err"></div><button class="btn" id="save">Save correction</button><button class="btn alt" id="bk">Cancel</button>`;
  $('bk').onclick = () => renderSaleDetail(host, saleId, back);
  $('save').onclick = async () => {
    const q = {}; host.querySelectorAll('[data-p]').forEach(e => (q[e.dataset.p] = e.value));
    try { await correctSale(saleId, q, $('why').value); renderSaleDetail(host, saleId, back); } catch (e) { $('err').textContent = e.message; }
  };
}
